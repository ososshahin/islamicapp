import 'package:flutter/material.dart';

class Radiotab extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return(Scaffold());
  }

}