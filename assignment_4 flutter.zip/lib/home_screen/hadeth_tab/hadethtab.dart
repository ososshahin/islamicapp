import 'package:flutter/material.dart';

class Hadethtab extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return(Scaffold());
  }

}